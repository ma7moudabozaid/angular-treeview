import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TahTreeviewComponent } from './components/tah-treeview/tah-treeview.component';
// import { TahTreeitemComponent } from './components/tah-treeview/tah-treeitem/tah-treeitem.component';
import { TahalufTreeviewModule } from 'projects/tahaluf-treeview/src/lib/tahaluf-treeview.module';
import { HomeComponent } from './components/home/home.component';
import { DynamicContentComponent } from './components/dynamic-content/dynamic-content.component';
import { TreeItemComponent } from './components/dynamic-content/tree-item/tree-item.component';
import { TreeComponent } from './components/dynamic-content/tree/tree.component';
import { TahTreeitemComponent } from './components/tah-treeview/tah-treeitem/tah-treeitem.component';

@NgModule({
  declarations: [
    AppComponent,
    TahTreeviewComponent,
    HomeComponent,
    DynamicContentComponent,
    TreeItemComponent,
    TreeComponent,
    TahTreeitemComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, TahalufTreeviewModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
