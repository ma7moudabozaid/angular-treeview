import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TahTreeviewComponent } from './components/tah-treeview/tah-treeview.component';
import { HomeComponent } from './components/home/home.component';
import { DynamicContentComponent } from './components/dynamic-content/dynamic-content.component';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  // { path: 'tree', component: TahTreeviewComponent },
  // { path: 'dynamic-content', component: DynamicContentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
