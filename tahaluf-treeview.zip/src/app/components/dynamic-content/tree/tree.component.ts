import { Component, Input, TemplateRef } from '@angular/core';
import { Tree } from 'src/app/models/tree';

@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss'],
})
export class TreeComponent {
  @Input() items: Tree[] = [];
  @Input() treeTemplate!: TemplateRef<any>;

  
  expand(item: any) {
    item.isExpand = !item.isExpand;
    console.log(item.id);
  }
}
