import { Component, Input, TemplateRef } from '@angular/core';

@Component({
  selector: 'app-tree-item',
  templateUrl: './tree-item.component.html',
  styleUrls: ['./tree-item.component.scss'],
})
export class TreeItemComponent {
  @Input() item: any;
  @Input() items: any;
  @Input() itemTemplate!: TemplateRef<any>;
}
