import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tah-treeitem',
  templateUrl: './tah-treeitem.component.html',
  styleUrls: ['./tah-treeitem.component.scss']
})
export class TahTreeitemComponent {
  @Input() items: any;

}
