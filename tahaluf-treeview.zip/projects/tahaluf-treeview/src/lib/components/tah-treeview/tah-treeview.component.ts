import {
  Component,
  ContentChild,
  EventEmitter,
  Input,
  Output,
  TemplateRef,
} from '@angular/core';
import { Tree } from 'src/app/models/tree';

@Component({
  selector: 'lib-tah-treeview',
  templateUrl: './tah-treeview.component.html',
  styleUrls: ['./tah-treeview.component.scss'],
})
export class TahTreeviewComponent {
  @Input() items: Tree[] = [];
  @Output() expandTree = new EventEmitter<number>();
  @ContentChild('optionTemplate', { static: false })
  optionTemplateRef!: TemplateRef<any>;
  constructor() {}

  ngOnInit(): void {}

  expand(item: any) {
    item.isExpand = !item.isExpand;
    console.log(item.id);
  }
}
