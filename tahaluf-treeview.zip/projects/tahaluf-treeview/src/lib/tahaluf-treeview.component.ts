import { Component } from '@angular/core';

@Component({
  selector: 'lib-tahalufTreeview',
  templateUrl: './tah-treeview.component.html',
  styleUrls: ['./tahaluf-treeview.component.scss'],
})
export class TahalufTreeviewComponent {}
